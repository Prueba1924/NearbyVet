document.getElementById("registro-form").addEventListener("submit", function(event) {
    event.preventDefault();
    const nombre = document.getElementById("nombre").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    if (nombre && email && password) {
        document.getElementById("registro-container").classList.add("hidden");
        document.getElementById("navbar").style.display = "flex";
        document.getElementById("inicio").classList.remove("hidden");
        document.getElementById("veterinarias").classList.remove("hidden");
        document.getElementById("productos").classList.remove("hidden");
        document.getElementById("asesorias").classList.remove("hidden");
        document.getElementById("consejos").classList.remove("hidden");
    } else {
        alert("Por favor, completa todos los campos.");
    }
});

document.getElementById("navbar-toggle").addEventListener("click", function() {
    const links = document.getElementById("navbar-links");
    if (links.style.display === "block") {
        links.style.display = "none";
    } else {
        links.style.display = "block";
    }
});

const navbarLinks = document.getElementById("navbar-links");
navbarLinks.addEventListener("click", function() {
    navbarLinks.style.display = "none"; // Ocultar el menú al hacer clic
});
